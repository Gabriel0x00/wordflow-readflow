import { readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { createHash } from 'node:crypto';

const dist = resolve(process.argv[2] || 'dist-pages');
const read = name => readFileSync(join(dist, name), 'utf8');
const write = (name, contents) => writeFileSync(join(dist, name), contents);
const original = read('index.html');
const match = original.match(/<script src="\/([^"]+)"[^>]*><\/script>/);
if (!match) throw new Error('No se encontró el paquete JavaScript de Expo.');
const originalBundle = match[1];
const scriptContents = read(originalBundle);
const bundle = 'app-' + createHash('sha256').update(scriptContents).digest('hex').slice(0, 16) + '.js';
write(bundle, scriptContents);
const resources = ['instalar.html', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'logo.png', 'sw.js'];
const digest = createHash('sha256').update(original).update(scriptContents);
for (const name of resources) digest.update(readFileSync(join(dist, name)));
const version = digest.digest('hex').slice(0, 16);
const metadata = [
  '<link rel="manifest" href="./manifest.webmanifest">',
  '<link rel="icon" href="./icon-192.png">',
  '<link rel="apple-touch-icon" href="./icon-192.png">',
  '<meta name="theme-color" content="#113D32">',
].join('\n    ');
const register = "<script>if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('./sw.js').catch(console.warn);</script>";
const page = original.replace('<html lang="en">', '<html lang="es">')
  .replace('</head>', '    ' + metadata + '\n  </head>')
  .replace(match[0], '<script src="./' + bundle + '" defer></script>\n  ' + register);
write('index.html', page);
write('sw.js', read('sw.js').replace('__BUILD_ID__', version).replace('__APP_SCRIPT__', bundle));
write('version.json', JSON.stringify({ version }));
if (process.argv[3]) {
  const icon = readFileSync(join(dist, 'icon-192.png')).toString('base64');
  const script = readFileSync(join(dist, bundle)).toString('base64');
  writeFileSync(resolve(process.argv[3]), page
    .replace('./icon-192.png"', 'data:image/png;base64,' + icon + '"')
    .replace('./' + bundle + '"', 'data:text/javascript;base64,' + script + '"')
    .replace(register, ''));
}

import React, { useState } from 'react';
import { Linking, View } from 'react-native';
import { days, reminders, validDate } from './plan.mjs';
import * as N from './notices';
import { flip, safeLink, whole } from './Forms';
import { Button, Card, Field, Sheet, Text, Title, wrap } from './ui';

export default function Settings({ settings, close, save, notice, activate, test, backup, restore }) {
  const [form, setForm] = useState(settings);
  const [error, setError] = useState('');
  const set = (name, value) => setForm(current => ({ ...current, [name]: value }));
  const field = (label, name, options = {}) => <Field label={label} value={String(form[name])} onChange={value => set(name, value)} {...options} />;
  function store() {
    const { pauseFrom, pauseTo, speakFlow, readingStudio, goal } = form;
    if (!whole(goal, 1, 10080)) { setError('Escribe una meta semanal válida en minutos.'); return; }
    if ((pauseFrom || pauseTo) && (!validDate(pauseFrom) || !validDate(pauseTo) || pauseFrom > pauseTo)) {
      setError('Para pausar, completa ambas fechas en orden y con formato AAAA-MM-DD.'); return;
    }
    if ([speakFlow, readingStudio].some(url => url.trim() && !safeLink(url.trim()))) {
      setError('Los enlaces deben comenzar con https:// o http://.'); return;
    }
    save({ ...form, goal: +goal, speakFlow: speakFlow.trim(), readingStudio: readingStudio.trim() });
  }
  return <Sheet title="Ajustes" close={close}>
    <Card>
      <Title size={20}>Recordatorios</Title>
      <Text muted>{notice}</Text>
      {N.supported && <View style={wrap}>
        <Button label="Activar avisos" onPress={activate} />
        <Button label="Aviso de prueba" onPress={test} />
        <Button label="Ajustes del celular" onPress={() => Linking.openSettings().catch(() => {})} />
      </View>}
      <Text weight="700">Anticipación general</Text>
      <View style={wrap}>{Object.entries(reminders).map(([value, label]) =>
        <Button key={value} kind="chip" label={label} selected={form.reminder === value} onPress={() => set('reminder', value)} />)}</View>
    </Card>
    <Card>
      <Title size={20}>Mi rutina</Title>
      {field('Meta semanal · Minutos', 'goal', { numeric: true })}
      <Text weight="700">Días de descanso</Text>
      <View style={wrap}>{days.map((day, i) =>
        <Button key={day} kind="chip" label={day} selected={form.rest.includes(i)} onPress={() => set('rest', flip(form.rest, i))} />)}</View>
      {field('Pausar desde · AAAA-MM-DD', 'pauseFrom')}
      {field('Pausar hasta · AAAA-MM-DD', 'pauseTo')}
      <Button label={form.balance ? '✓ Sugerencias de balance' : 'Activar sugerencias de balance'} selected={form.balance} onPress={() => set('balance', !form.balance)} />
    </Card>
    <Card>
      <Title size={20}>Accesos rápidos</Title>
      {field('Enlace de SpeakFlow', 'speakFlow', { placeholder: 'https://' })}
      {field('Enlace de Reading Studio', 'readingStudio', { placeholder: 'https://' })}
    </Card>
    <Card>
      <Title size={20}>Apariencia</Title>
      <View style={wrap}>{Object.entries({ system: 'Sistema', light: 'Claro', dark: 'Oscuro' }).map(([value, label]) =>
        <Button key={value} kind="chip" label={label} selected={form.theme === value} onPress={() => set('theme', value)} />)}</View>
    </Card>
    <Card>
      <Title size={20}>Copia de seguridad</Title>
      <Text muted>Incluye el horario, el progreso, las notas y las frases. Las grabaciones se conservan en su teléfono.</Text>
      <View style={wrap}><Button label="Exportar copia" onPress={backup} /><Button label="Restaurar copia" onPress={restore} /></View>
    </Card>
    {!!error && <Text accessibilityRole="alert">{error}</Text>}
    <Button kind="solid" label="Guardar ajustes" onPress={store} />
  </Sheet>;
}

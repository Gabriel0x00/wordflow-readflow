export const supported = false;
export async function prepare() {}
export async function permission() { return false; }
export async function reconcile() { return null; }
export async function testNotice() {}
export function listen() { return () => {}; }
export async function clearResponse() {}

import React, { createContext, useContext } from 'react';
import { Modal, Pressable, ScrollView, Text as NativeText, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export const light = { bg: '#F2F5EF', card: '#FFFFFF', ink: '#162F27', muted: '#4E6359', line: '#D9E3DA', brand: '#1B5847', soft: '#DFEEE3', hero: '#113D32', lime: '#D9F391', white: '#FFFFFF' };
export const dark = { bg: '#111E19', card: '#1A2B23', ink: '#EDF4EB', muted: '#B3C6B9', line: '#34483C', brand: '#ACDDB9', soft: '#2A4133', hero: '#173D30', lime: '#D9F391', white: '#FFFFFF' };
export const Theme = createContext(light);
export const useTheme = () => useContext(Theme);
export const row = { flexDirection: 'row', alignItems: 'center', gap: 9 };
export const wrap = { ...row, flexWrap: 'wrap' };
export const between = { ...row, justifyContent: 'space-between' };

export function Text({ children, muted, size = 15, weight = '400', color, style, ...props }) {
  const p = useTheme();
  return <NativeText {...props} style={[{ color: color || (muted ? p.muted : p.ink), fontSize: size, fontWeight: weight }, style]}>{children}</NativeText>;
}
export const Title = ({ children, size = 29 }) => <Text accessibilityRole="header" size={size} weight="800">{children}</Text>;

export function Button({ label, onPress, kind = 'plain', style, disabled = false, selected = false, accessibilityLabel }) {
  const p = useTheme();
  const solid = kind === 'solid';
  const bright = kind === 'bright';
  const color = bright ? '#173328' : solid ? p.bg : p.ink;
  return <Pressable accessibilityRole="button" accessibilityLabel={accessibilityLabel || label}
    accessibilityState={{ disabled, selected }} disabled={disabled} onPress={onPress}
    style={({ pressed }) => [{ backgroundColor: solid ? p.brand : bright ? p.lime : selected ? p.soft : p.card,
      borderColor: selected ? p.brand : p.line, borderWidth: solid || bright ? 0 : 1, borderRadius: 12,
      minHeight: kind === 'chip' ? 40 : 46, justifyContent: 'center', paddingHorizontal: 13,
      paddingVertical: 7, opacity: disabled ? 0.45 : pressed ? 0.72 : 1 }, style]}>
    <Text size={kind === 'chip' ? 13 : 14} color={color} weight="700" style={{ textAlign: 'center' }}>{label}</Text>
  </Pressable>;
}
export function Card({ children, style }) {
  const p = useTheme();
  return <View style={[{ backgroundColor: p.card, borderColor: p.line, borderWidth: 1, borderRadius: 19,
    padding: 16, gap: 10 }, style]}>{children}</View>;
}
export function Field({ label, value, onChange, placeholder, multiline, numeric = false }) {
  const p = useTheme();
  return <View style={{ gap: 6 }}>
    <Text weight="700" size={14}>{label}</Text>
    <TextInput accessibilityLabel={label} value={value} onChangeText={onChange} placeholder={placeholder}
      placeholderTextColor={p.muted} multiline={multiline} keyboardType={numeric ? 'number-pad' : 'default'}
      style={{ borderColor: p.line, borderWidth: 1, padding: 12, minHeight: multiline ? 76 : 46,
        backgroundColor: p.card, borderRadius: 11, color: p.ink, fontSize: 15, textAlignVertical: multiline ? 'top' : 'center' }} />
  </View>;
}
export function Sheet({ title, close, children }) {
  const p = useTheme();
  return <Modal visible animationType="slide" presentationStyle="fullScreen" onRequestClose={close}>
    <SafeAreaView style={{ flex: 1, backgroundColor: p.bg }}>
      <View style={{ width: '100%', maxWidth: 680, flex: 1, alignSelf: 'center' }}>
        <View style={{ ...between, paddingHorizontal: 20, paddingVertical: 12 }}>
          <View style={{ flex: 1 }}><Title size={23}>{title}</Title></View>
          <Button label="Cerrar" onPress={close} />
        </View>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 20, paddingTop: 8, paddingBottom: 38, gap: 14 }}>
          {children}
        </ScrollView>
      </View>
    </SafeAreaView>
  </Modal>;
}
export function Bar({ value, color, track, label }) {
  const p = useTheme();
  const percent = Math.max(0, Math.min(100, Math.round(value * 100)));
  return <View accessibilityRole="progressbar" accessibilityLabel={label}
    accessibilityValue={{ min: 0, max: 100, now: percent }}
    style={{ height: 8, borderRadius: 8, backgroundColor: track || p.soft, overflow: 'hidden' }}>
    <View style={{ width: percent + '%', height: '100%', backgroundColor: color || p.brand, borderRadius: 8 }} />
  </View>;
}

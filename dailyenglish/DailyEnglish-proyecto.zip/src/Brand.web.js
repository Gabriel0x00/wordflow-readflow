import React from 'react';
import { Image } from 'react-native';

export default function Brand() {
  const uri = document.querySelector('link[rel="icon"]')?.href || './icon-192.png';
  return <Image source={{ uri }} style={{ width: 38, height: 38, borderRadius: 10 }} />;
}

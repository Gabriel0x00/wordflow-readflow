import { Platform } from 'react-native';
import * as N from 'expo-notifications';
import { pendingReminders } from './plan.mjs';

const channelId = 'estudio';
const categoryIdentifier = 'estudio';
const type = N.SchedulableTriggerInputTypes.DATE;
N.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false,
  }),
});

export const supported = true;
export async function prepare() {
  if (Platform.OS === 'android') {
    await N.setNotificationChannelAsync(channelId, {
      name: 'Sesiones de inglés', importance: N.AndroidImportance.HIGH,
    });
  }
  await N.setNotificationCategoryAsync(categoryIdentifier, [
    { identifier: 'start', buttonTitle: 'Empezar', options: { opensAppToForeground: true } },
    { identifier: 'snooze', buttonTitle: 'Posponer 15 min', options: { opensAppToForeground: true } },
  ]);
}
const allowed = status => status.granted || status.ios?.status === N.IosAuthorizationStatus.PROVISIONAL;
export async function permission(request = false) {
  const current = await N.getPermissionsAsync();
  if (!request || allowed(current)) return allowed(current);
  return allowed(await N.requestPermissionsAsync());
}
export function testNotice() {
  return N.scheduleNotificationAsync({
    content: { title: 'DailyEnglish', body: 'Tu aviso de prueba ha llegado.', sound: 'default' },
    trigger: { type, date: new Date(Date.now() + 12_000), channelId },
  });
}
export function listen(callback) {
  const subscription = N.addNotificationResponseReceivedListener(callback);
  const last = N.getLastNotificationResponse();
  if (last) callback(last);
  return () => subscription.remove();
}
export const clearResponse = () => N.clearLastNotificationResponseAsync();

let queue = Promise.resolve();
export function reconcile(state) {
  const run = queue.catch(() => {}).then(async () => {
    if (!await permission()) return null;
    const wanted = pendingReminders(state);
    const desired = new Map(wanted.map(item => [item.id, item]));
    const existing = (await N.getAllScheduledNotificationsAsync()).filter(item => item.identifier.startsWith('study-'));
    const unchanged = new Set();
    for (const item of existing) {
      const match = desired.get(item.identifier);
      if (match && item.content.body === body(match.block)) unchanged.add(item.identifier);
      else await N.cancelScheduledNotificationAsync(item.identifier);
    }
    for (const item of wanted) {
      if (unchanged.has(item.id) || item.at <= Date.now()) continue;
      await N.scheduleNotificationAsync({
        identifier: item.id,
        content: {
          title: item.before ? 'En 10 minutos toca inglés' : 'Es hora de estudiar inglés',
          body: body(item.block), sound: 'default', categoryIdentifier,
          data: { occurrenceId: item.block.occurrenceId, date: item.block.date },
        },
        trigger: { type, date: new Date(item.at), channelId },
      });
    }
    return { count: wanted.length, until: wanted.at(-1)?.at };
  });
  queue = run;
  return run;
}
function body(block) {
  return [block.skill, block.minutes + ' min', block.objective || block.title].filter(Boolean).join(' · ');
}

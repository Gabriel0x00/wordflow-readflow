import React from 'react';
export default function Recording({ Text }) {
  return <Text muted>La grabación está disponible en la app móvil.</Text>;
}

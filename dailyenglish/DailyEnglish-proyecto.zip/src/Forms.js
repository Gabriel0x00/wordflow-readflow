import React, { useState } from 'react';
import { View } from 'react-native';
import { addDays, days, id, monday, reminders, skills, templates, makeTemplate, validDate, validTime, weekday } from './plan.mjs';
import { Button, Card, Field, Sheet, Text, Title, wrap } from './ui';

export const whole = (value, min, max) => /^\d+$/.test(value) && Number(value) >= min && Number(value) <= max;
export const flip = (items, value) => items.includes(value) ? items.filter(item => item !== value) : [...items, value];
export const safeLink = value => /^https?:\/\/[^\s/]+(?:\/[^\s]*)?$/i.test(value);

export function BlockForm({ block, date, scope, save, close, cancel }) {
  const [form, setForm] = useState(() => ({
    skill: 'Listening', title: '', date, time: '19:00', minutes: 25, days: [], until: '', objective: '', link: '',
    reminder: '', focus: 25, rest: 5, ...block, tasks: block?.tasks?.join('\n') || '',
    ...(scope === 'one' ? { days: [], until: '' } : {}),
  }));
  const [error, setError] = useState('');
  const patch = (name, value) => setForm(current => ({ ...current, [name]: value }));
  const field = (label, name, options = {}) => <Field label={label} value={String(form[name])} onChange={value => patch(name, value)} {...options} />;
  function submit() {
    if (!validDate(form.date) || (form.until && (!validDate(form.until) || form.until < form.date))) {
      setError('Revisa las fechas. Usa el formato AAAA-MM-DD.');
    } else if (!validTime(form.time)) {
      setError('Usa una hora de 24 horas, como 19:00.');
    } else if (!whole(form.minutes, 1, 720) || !whole(form.focus, 1, 180) || !whole(form.rest, 1, 60)) {
      setError('Revisa la duración de la sesión y los tiempos del Pomodoro.');
    } else if (form.link.trim() && !safeLink(form.link.trim())) {
      setError('Agrega un enlace completo que empiece por https:// o http://.');
    } else {
      save({ ...form, id: form.id || id(), link: form.link.trim(), minutes: +form.minutes,
        focus: +form.focus, rest: +form.rest, tasks: form.tasks.split('\n').map(value => value.trim()).filter(Boolean) });
    }
  }
  return <Sheet title={scope === 'one' ? 'Editar esta sesión' : block?.id ? 'Editar horario' : 'Nueva sesión'} close={close}>
    <Text weight="800">Habilidad</Text>
    <View style={wrap}>{Object.entries(skills).map(([skill, values]) =>
      <Button key={skill} kind="chip" label={values[0] + ' ' + skill} selected={form.skill === skill} onPress={() => patch('skill', skill)} />)}</View>
    {field('Nombre opcional', 'title', { placeholder: 'Conversación sobre mi rutina' })}
    <View style={wrap}>
      <View style={{ flex: 1, minWidth: 140 }}>{field('Fecha', 'date', { placeholder: 'AAAA-MM-DD' })}</View>
      <View style={{ flex: 1, minWidth: 90 }}>{field('Hora', 'time', { placeholder: '19:00' })}</View>
      <View style={{ flex: 1, minWidth: 90 }}>{field('Minutos', 'minutes', { numeric: true })}</View>
    </View>
    {scope !== 'one' && <>
      <Text weight="800">Repetir cada semana</Text>
      <View style={wrap}>{days.map((day, index) =>
        <Button key={day} kind="chip" label={day} selected={form.days.includes(index)} onPress={() => patch('days', flip(form.days, index))} />)}</View>
      {form.days.length > 0 ? field('Última fecha opcional', 'until', { placeholder: 'AAAA-MM-DD' }) : <Text muted>Sesión de una sola fecha</Text>}
    </>}
    {field('Objetivo', 'objective', { placeholder: 'Entender un video y anotar tres frases' })}
    {field('Checklist · Una tarea por línea', 'tasks', { multiline: true, placeholder: 'Shadowing 15 min\nLeer un texto corto' })}
    {field('Enlace del material', 'link', { placeholder: 'https://' })}
    <Text weight="800">Recordatorio</Text>
    <View style={wrap}>{Object.entries({ '': 'Usar ajuste general', ...reminders }).map(([value, label]) =>
      <Button key={value} kind="chip" label={label} selected={form.reminder === value} onPress={() => patch('reminder', value)} />)}</View>
    <View style={wrap}>
      <View style={{ flex: 1 }}>{field('Pomodoro · Estudio', 'focus', { numeric: true })}</View>
      <View style={{ flex: 1 }}>{field('Descanso', 'rest', { numeric: true })}</View>
    </View>
    {!!error && <Text accessibilityRole="alert">{error}</Text>}
    <Button label="Guardar sesión" kind="solid" onPress={submit} />
    {!!cancel && <Button label={scope === 'one' ? 'Cancelar esta sesión' : 'Eliminar horario'} onPress={cancel} />}
  </Sheet>;
}

export function TemplateForm({ date, close, apply, custom = [], weekToSave, onSave }) {
  const [choice, setChoice] = useState('b2');
  const [start, setStart] = useState(monday(addDays(date, weekday(date) ? 7 : 0)));
  const [time, setTime] = useState('19:00');
  const [useGoal, setUseGoal] = useState(true);
  const [name, setName] = useState('');
  const personal = custom.find(item => item.id === choice);
  const valid = validDate(start) && (personal || validTime(time));
  const startWeek = valid ? monday(start) : '';
  const preview = !valid ? [] : personal ? personal.blocks.map(item => ({
    ...item, id: id(), date: addDays(startWeek, item.day), until: '', days: [item.day], time: item.time,
  })) : makeTemplate(choice, startWeek, time);
  const goal = personal?.goal || templates[choice]?.goal || 0;
  return <Sheet title="Plantillas" close={close}>
    {Object.entries(templates).map(([value, item]) => <Card key={value}>
      <Title size={19}>{item.title}</Title><Text muted>{item.description}</Text>
      <Button label={choice === value ? 'Seleccionada' : 'Ver plan'} selected={choice === value} onPress={() => setChoice(value)} />
    </Card>)}
    {custom.map(item => <Card key={item.id}>
      <Title size={19}>{item.name}</Title><Text muted>{item.blocks.length} bloques con tus horas guardadas</Text>
      <Button label={choice === item.id ? 'Seleccionada' : 'Ver plan'} selected={choice === item.id} onPress={() => setChoice(item.id)} />
    </Card>)}
    <Field label="Semana de inicio · AAAA-MM-DD" value={start} onChange={setStart} />
    {!personal && <Field label="Hora inicial · HH:MM" value={time} onChange={setTime} />}
    {!!preview.length && <Card>
      <Text weight="800">Primera semana · {startWeek}</Text>
      {preview.filter(item => personal || item.date === startWeek).map(item =>
        <Text key={item.id}>{days[item.days[0]]} · {item.time} · {item.skill} · {item.minutes} min</Text>)}
      <Text muted>{goal} min de meta semanal. Puedes editar tus sesiones en Horario.</Text>
    </Card>}
    <Button selected={useGoal} label={useGoal ? '✓ Usar la meta de la plantilla' : 'Mantener mi meta semanal'} onPress={() => setUseGoal(!useGoal)} />
    <Button disabled={!preview.length} kind="solid" label="Añadir al horario" onPress={() => apply(preview, useGoal ? goal : null)} />
    {!!weekToSave.length && <Card>
      <Title size={18}>Guardar semana como plantilla</Title>
      <Field label="Nombre de tu plantilla" value={name} onChange={setName} />
      <Button label="Guardar plantilla" disabled={!name.trim()} onPress={() => {
        setChoice(onSave(name.trim(), weekToSave)); setName('');
      }} />
    </Card>}
  </Sheet>;
}

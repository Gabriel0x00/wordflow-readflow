import React from 'react';
import { Image } from 'react-native';

export default function Brand() {
  return <Image accessibilityIgnoresInvertColors source={require('../public/icon-192.png')} style={{ width: 38, height: 38, borderRadius: 10 }} />;
}

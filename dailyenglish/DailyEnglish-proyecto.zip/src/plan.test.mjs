import assert from 'node:assert/strict';
import { test } from 'node:test';
import { blocksOn, initialState, makeTemplate, pendingReminders, streak, weekStats, when } from './plan.mjs';

const monday = '2026-11-23';
const tuesday = '2026-11-24';
const block = { id: 'speaking', date: monday, days: [0], time: '19:00', skill: 'Speaking', reminder: 'both', minutes: 25 };
const entry = 'speaking@' + monday;

test('moving one occurrence reschedules both alerts and preserves next week', () => {
  const state = { ...initialState(), blocks: [block], overrides: { [entry]: { ...block, occurrenceId: entry, date: tuesday } } };
  assert.equal(blocksOn(state, monday).length, 0);
  assert.equal(blocksOn(state, tuesday)[0].occurrenceId, entry);
  assert.equal(blocksOn(state, '2026-11-30').length, 1);
  const notices = pendingReminders(state, when(monday, '09:00'));
  assert.deepEqual(notices.slice(0, 2).map(item => item.at), [when(tuesday, '18:50'), when(tuesday, '19:00')]);
});

test('starting or finishing removes pending alerts for that occurrence only', () => {
  const state = { ...initialState(), blocks: [block], logs: { [entry]: { started: true } } };
  const next = pendingReminders(state, when(monday, '18:51'));
  assert.equal(next[0].block.date, '2026-11-30');
  state.logs[entry] = { done: true, minutes: 20, skill: 'Speaking', date: monday };
  assert.equal(weekStats(state, monday).bySkill.Speaking, 20);
  assert.equal(pendingReminders(state, when(monday, '18:51'))[0].block.date, '2026-11-30');
});

test('an alert postponed across midnight stays scheduled', () => {
  const once = { ...block, time: '23:55', days: [] };
  const state = { ...initialState(), blocks: [once], logs: { [entry]: { snooze: when(tuesday, '00:10') } } };
  assert.equal(pendingReminders(state, when(tuesday, '00:05'))[0].at, when(tuesday, '00:10'));
});

test('B2 fills eight weeks, and vacation suppresses notices', () => {
  const state = initialState();
  state.blocks = makeTemplate('b2', monday, '19:00');
  assert.equal(blocksOn(state, '2027-01-11').length, 1);
  assert.equal(blocksOn(state, '2027-01-18').length, 0);
  state.settings.pauseFrom = monday;
  state.settings.pauseTo = tuesday;
  assert.equal(pendingReminders(state, when(monday, '09:00'))[0].block.date, '2026-11-25');
});

test('planned rest lets a study streak continue across Sunday', () => {
  const state = initialState();
  state.logs = Object.fromEntries(['2026-11-21', monday].map(date => [date, { date, done: true }]));
  assert.equal(streak(state, monday), 2);
});

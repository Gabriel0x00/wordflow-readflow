import React, { useEffect, useState } from 'react';
import { Linking, View } from 'react-native';
import { id, skills } from './plan.mjs';
import { safeLink, whole } from './Forms';
import { Bar, Button, Card, Field, Sheet, Text, Title, between, useTheme, wrap } from './ui';
import Recording from './Recording';

export default function Session({ block, log, update, settings, edit, close, addPhrase, phrases }) {
  const p = useTheme();
  const [current, setCurrent] = useState(Date.now());
  const [minutes, setMinutes] = useState(null);
  const [phrase, setPhrase] = useState('');
  const [error, setError] = useState('');
  const icon = skills[block.skill][0];
  const { phase = 'focus', end = null, left = block.focus * 60, seconds = 0 } = log.timer || {};
  const remaining = end ? Math.max(0, Math.ceil((end - current) / 1000)) : left;
  const count = seconds + (end && phase === 'focus' ? Math.max(0, left - remaining) : 0);
  const recorded = String(Math.max(1, Math.ceil(count / 60) || block.minutes));
  const display = [Math.floor(remaining / 60), remaining % 60].map(value => String(value).padStart(2, '0')).join(':');

  useEffect(() => {
    if (!end || log.done) return;
    setCurrent(Date.now());
    const tick = setInterval(() => setCurrent(Date.now()), 350);
    return () => clearInterval(tick);
  }, [end, log.done]);
  useEffect(() => {
    if (end && remaining === 0 && !log.done) {
      update({ timer: {
        phase: phase === 'focus' ? 'rest' : 'focus', end: null,
        left: (phase === 'focus' ? block.rest : block.focus) * 60, seconds: count,
      } });
    }
  }, [end, remaining, log.done, phase, block.rest, block.focus, count, update]);

  async function open(url) {
    try { await Linking.openURL(url); }
    catch { setError('No se pudo abrir ese enlace. Revísalo en los ajustes o en la sesión.'); }
  }
  function done() {
    const total = minutes ?? recorded;
    if (!whole(total, 1, 720)) { setError('Escribe entre 1 y 720 minutos.'); return; }
    update({ done: true, minutes: +total, snooze: null, timer: null });
    close();
  }
  const links = [
    ['Abrir material', block.link], ['Abrir SpeakFlow', settings.speakFlow], ['Abrir Reading Studio', settings.readingStudio],
  ].filter(([, url]) => safeLink(url || ''));
  return <Sheet title={icon + '  ' + block.skill} close={close}>
    <Card>
      <View style={between}><Text weight="800">{block.date} · {block.time}</Text><Text muted>{block.minutes} min</Text></View>
      {!!block.title && <Title size={23}>{block.title}</Title>}
      {!!block.objective && <Text>{block.objective}</Text>}
      <View style={wrap}>
        <Button label="Editar o mover" onPress={edit} />
        {!log.done && <Button label="Posponer aviso 15 min" onPress={() => update({ snooze: Date.now() + 900_000 })} />}
      </View>
      {log.snooze > Date.now() && <Text muted>Aviso pospuesto.</Text>}
    </Card>
    {!log.done && <Card style={{ backgroundColor: p.hero }}>
      <Text weight="800" color={p.lime}>{phase === 'focus' ? 'Pomodoro · Estudio' : 'Pomodoro · Descanso'}</Text>
      <Text size={51} weight="800" color={p.white} style={{ fontVariant: ['tabular-nums'] }}>{display}</Text>
      <Bar value={1 - remaining / ((phase === 'focus' ? block.focus : block.rest) * 60)} color={p.lime} track="#426858" label="Avance del temporizador" />
      <View style={wrap}>
        <Button kind="bright" label={end ? 'Pausar' : 'Iniciar temporizador'} onPress={() => {
          const now = Date.now();
          setCurrent(now);
          const actualLeft = end ? Math.max(0, Math.ceil((end - now) / 1000)) : left;
          update({ started: true, snooze: null, timer: end
            ? { phase, left: actualLeft, end: null, seconds: seconds + (phase === 'focus' ? left - actualLeft : 0) }
            : { phase, left, end: now + left * 1000, seconds } });
        }} />
        <Button label="Siguiente fase" onPress={() => update({ timer: {
          phase: phase === 'focus' ? 'rest' : 'focus', end: null,
          left: (phase === 'focus' ? block.rest : block.focus) * 60, seconds: count,
        } })} />
      </View>
    </Card>}
    {!!block.tasks.length && <Card>
      <Title size={19}>Checklist</Title>
      {block.tasks.map((task, index) => <Button key={index}
        label={(log.checked?.includes(task) ? '☑ ' : '☐ ') + task}
        selected={log.checked?.includes(task)}
        onPress={() => {
          const checked = log.checked || [];
          update({ checked: checked.includes(task) ? checked.filter(value => value !== task) : [...checked, task] });
        }} />)}
    </Card>}
    {!!links.length && <View style={wrap}>{links.map(([label, url]) => <Button key={label} label={label + ' ↗'} onPress={() => open(url)} />)}</View>}
    <Card>
      <Field label="Notas del estudio" value={log.note || ''} onChange={note => update({ note })} multiline placeholder="¿Qué practicaste hoy?" />
      <Field label="Frase para repasar" value={phrase} onChange={setPhrase} placeholder="I’m getting the hang of it." />
      <Button label="Guardar frase" disabled={!phrase.trim()} onPress={() => {
        addPhrase({ id: id(), text: phrase.trim(), date: block.date, occurrenceId: block.occurrenceId });
        setPhrase('');
      }} />
      {!!phrases.length && <Button label="Añadir última frase al checklist" onPress={() => edit(phrases.at(-1).text)} />}
    </Card>
    {block.skill === 'Speaking' && <Card>
      <Title size={19}>Práctica grabada</Title>
      <Recording uri={log.recording} save={recording => update({ recording })} Button={Button} Text={Text} />
    </Card>}
    {!log.done && <>
      <Field label="Minutos estudiados" numeric value={minutes ?? recorded} onChange={setMinutes} />
      <Button kind="solid" label="Marcar como hecha" onPress={done} />
    </>}
    {log.done && <Text weight="800">✓ Sesión hecha · {log.minutes} min</Text>}
    {!!error && <Text accessibilityRole="alert">{error}</Text>}
  </Sheet>;
}

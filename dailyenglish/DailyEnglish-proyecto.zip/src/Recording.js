import React, { useEffect, useState } from 'react';
import { AudioModule, RecordingPresets, setAudioModeAsync, useAudioPlayer, useAudioRecorder } from 'expo-audio';
import { File, Paths } from 'expo-file-system';
import { id } from './plan.mjs';

export default function Recording({ uri, save, Button, Text }) {
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const player = useAudioPlayer(uri || null);
  const [active, setActive] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => () => { setAudioModeAsync({ allowsRecording: false }).catch(() => {}); }, []);

  async function toggle() {
    setBusy(true);
    setError('');
    try {
      if (active) {
        await recorder.stop();
        setActive(false);
        await setAudioModeAsync({ allowsRecording: false });
        if (!recorder.uri) throw new Error('Falta el archivo');
        const source = new File(recorder.uri);
        const target = new File(Paths.document, 'speaking-' + id() + source.extension);
        source.copy(target);
        save(target.uri);
      } else {
        const permission = await AudioModule.requestRecordingPermissionsAsync();
        if (!permission.granted) {
          setError('Activa el permiso de micrófono para grabar.');
          return;
        }
        player.pause();
        await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
        await recorder.prepareToRecordAsync();
        recorder.record();
        setActive(true);
      }
    } catch {
      setError('No se pudo usar el micrófono o guardar la grabación.');
    } finally {
      setBusy(false);
    }
  }
  return <>
    <Button label={active ? '■ Detener y guardar' : uri ? 'Grabar de nuevo' : '● Grabar speaking'} onPress={toggle} disabled={busy} />
    {!!uri && !active && <Button label="▶ Escuchar grabación" onPress={async () => {
      try { await player.seekTo(0); player.play(); }
      catch { setError('No se pudo reproducir la grabación.'); }
    }} />}
    {!!error && <Text muted>{error}</Text>}
  </>;
}

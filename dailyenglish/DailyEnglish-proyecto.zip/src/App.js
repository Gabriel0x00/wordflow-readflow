import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, Pressable, ScrollView, StatusBar, View, useColorScheme, useWindowDimensions } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { addDays, blocksOn, days, initialState, key, fromKey, monday, pausedOn, skills, streak, validDate, validTime, reminders, weekStats, weekday, id } from './plan.mjs';
import * as N from './notices';
import { exportBackup, importBackup } from './backup';
import { BlockForm, TemplateForm } from './Forms';
import Session from './Session';
import Settings from './Settings';
import Brand from './Brand';
import { Bar, Button, Card, Sheet, Text, Theme, Title, between, dark, light, row, useTheme, wrap } from './ui';

const storage = 'dailyenglish.v1';
const tabs = [['▣', 'Hoy'], ['▦', 'Horario'], ['◷', 'Progreso']];
const shortDate = date => fromKey(date).toLocaleDateString('es', { day: 'numeric', month: 'short' });
const longDate = date => {
  const label = fromKey(date).toLocaleDateString('es', { weekday: 'long', day: 'numeric', month: 'long' });
  return label.charAt(0).toLocaleUpperCase('es') + label.slice(1);
};
const duration = mins => mins < 60 ? mins + ' min' : Math.floor(mins / 60) + ' h' + (mins % 60 ? ' ' + mins % 60 + ' min' : '');
const blankLog = Object.freeze({});
const record = value => value && typeof value === 'object' && !Array.isArray(value);
function validate(data) {
  const block = value => record(value) && typeof value.id === 'string' && Object.hasOwn(skills, value.skill)
    && validDate(value.date) && validTime(value.time) && Array.isArray(value.days) && value.days.every(day => Number.isInteger(day) && day >= 0 && day <= 6)
    && Array.isArray(value.tasks) && value.tasks.every(task => typeof task === 'string')
    && ['title', 'objective', 'link'].every(field => typeof value[field] === 'string')
    && ['', ...Object.keys(reminders)].includes(value.reminder) && (!value.until || validDate(value.until))
    && ['minutes', 'focus', 'rest'].every(field => Number.isInteger(value[field]) && value[field] > 0);
  if (!record(data) || data.version !== 1 || !Array.isArray(data.blocks) || !data.blocks.every(block)
    || !record(data.overrides) || !Object.values(data.overrides).every(value => record(value) && (value.cancelled === true || block(value)))
    || !record(data.logs) || !Object.values(data.logs).every(value => record(value) && validDate(value.date)
      && (!value.done || (Number.isInteger(value.minutes) && value.minutes > 0)) && (!value.block || block(value.block)))
    || !Array.isArray(data.phrases) || !data.phrases.every(phrase => record(phrase) && typeof phrase.text === 'string')
    || !record(data.settings) || !Number.isInteger(data.settings.goal) || data.settings.goal < 1 || !Array.isArray(data.settings.rest)) {
    throw new Error('Formato no válido');
  }
  return { ...data, customTemplates: Array.isArray(data.customTemplates)
    ? data.customTemplates.filter(item => record(item) && typeof item.id === 'string' && typeof item.name === 'string'
      && Number.isInteger(item.goal) && Array.isArray(item.blocks) && item.blocks.every(value => block(value)
        && Number.isInteger(value.day) && value.day >= 0 && value.day <= 6))
    : [] };
}

function SessionTile({ block, log, onPress }) {
  const p = useTheme();
  const [icon, fill, ink, accent] = skills[block.skill];
  return <Pressable accessibilityRole="button" accessibilityLabel={block.skill + ', ' + block.time + ', ' + block.minutes + ' minutos'} onPress={onPress}
    style={({ pressed }) => ({ backgroundColor: p === dark ? p.card : fill, borderLeftColor: accent, borderLeftWidth: 5,
      borderRadius: 13, padding: 12, gap: 4, opacity: pressed ? 0.72 : 1 })}>
    <Text weight="800" color={p === dark ? p.ink : ink}>{icon}  {block.skill}</Text>
    <Text size={13} color={p === dark ? p.muted : ink}>{block.time} · {block.minutes} min{log?.done ? ' · ✓ Hecha' : ''}</Text>
    {!!block.title && <Text size={13} color={p === dark ? p.muted : ink}>{block.title}</Text>}
  </Pressable>;
}

function AppContent() {
  const systemTheme = useColorScheme();
  const { width } = useWindowDimensions();
  const [state, setState] = useState(initialState);
  const stateRef = useRef(state);
  const writes = useRef(Promise.resolve());
  const [ready, setReady] = useState(false);
  const [today, setToday] = useState(key);
  const [view, setView] = useState('Hoy');
  const [week, setWeek] = useState(() => monday(key()));
  const [day, setDay] = useState(key);
  const [modal, setModal] = useState(null);
  const [message, setMessage] = useState('');
  const [notice, setNotice] = useState(N.supported ? 'Comprobando permisos…' : 'Los recordatorios del teléfono están disponibles en la app móvil.');
  const isDark = state.settings.theme === 'dark' || (state.settings.theme === 'system' && systemTheme === 'dark');
  const p = isDark ? dark : light;
  const scroll = useRef(null);
  const previousResponse = useRef('');

  const commit = useCallback(update => {
    const nextState = update(stateRef.current);
    stateRef.current = nextState;
    setState(nextState);
    const save = writes.current.catch(() => {}).then(() => AsyncStorage.setItem(storage, JSON.stringify(nextState)));
    writes.current = save;
    save.catch(() => setMessage('No se pudieron guardar los cambios en este dispositivo.'));
  }, []);

  useEffect(() => {
    let alive = true;
    AsyncStorage.getItem(storage).then(raw => {
      if (raw && alive) {
        const restored = validate(JSON.parse(raw));
        stateRef.current = restored;
        setState(restored);
      }
    }).catch(() => setMessage('No se pudo leer el horario guardado.'))
      .finally(() => { if (alive) setReady(true); });
    return () => { alive = false; };
  }, []);

  const sync = useCallback(async (request = false, test = false) => {
    if (!N.supported) return;
    try {
      await N.prepare();
      const enabled = await N.permission(request);
      if (!enabled) { setNotice('Permiso pendiente. Activa los avisos para recibir recordatorios.'); return; }
      const result = await N.reconcile(stateRef.current);
      if (test) {
        await N.testNotice();
        setMessage('Aviso de prueba programado en 12 segundos.');
      }
      setNotice(result?.count
        ? result.count + ' avisos programados hasta el ' + shortDate(key(new Date(result.until))) + '. Se renuevan al abrir la app.'
        : 'Avisos autorizados. Puedes programarlos al crear una sesión.');
      if (test) setNotice('Aviso de prueba programado. Bloquea la pantalla y espera 12 segundos.');
    } catch {
      setNotice('No se pudieron programar todos los avisos. Revisa los permisos de notificaciones y alarmas del teléfono.');
    }
  }, []);

  useEffect(() => {
    if (!ready) return;
    const sub = AppState.addEventListener('change', status => {
      if (status === 'active') { setToday(key()); sync(); }
    });
    const timer = setInterval(() => setToday(key()), 15_000);
    return () => { sub.remove(); clearInterval(timer); };
  }, [ready, sync]);

  const scheduleData = JSON.stringify({
    blocks: state.blocks, overrides: state.overrides, reminder: state.settings.reminder,
    pauseFrom: state.settings.pauseFrom, pauseTo: state.settings.pauseTo,
    logs: Object.entries(state.logs).filter(([, log]) => log.started || log.done || log.snooze)
      .map(([entry, log]) => [entry, log.started, log.done, log.snooze]),
  });
  useEffect(() => { if (ready) sync(); }, [ready, scheduleData, sync, today]);

  const updateLog = useCallback((block, changes) => commit(current => ({
    ...current,
    logs: { ...current.logs, [block.occurrenceId]: {
      ...current.logs[block.occurrenceId], block, date: block.date, skill: block.skill, ...changes,
    } },
  })), [commit]);

  useEffect(() => {
    if (!ready) return;
    return N.listen(response => {
      const request = response.notification.request;
      const { occurrenceId, date } = request.content.data || {};
      if (!occurrenceId || previousResponse.current === request.identifier) return;
      previousResponse.current = request.identifier;
      N.clearResponse().catch(() => {});
      if (!validDate(date)) return;
      const block = blocksOn(stateRef.current, date).find(entry => entry.occurrenceId === occurrenceId);
      if (!block || stateRef.current.logs[occurrenceId]?.done || pausedOn(stateRef.current, date)) return;
      if (response.actionIdentifier === 'snooze') {
        updateLog(block, { snooze: Date.now() + 900_000 });
        setMessage('Aviso pospuesto 15 minutos.');
      } else {
        updateLog(block, { started: true, snooze: null });
        setModal({ type: 'session', block });
      }
    });
  }, [ready, updateLog]);

  const stats = weekStats(state, today);
  const ratio = stats.minutes / state.settings.goal;
  const session = block => setModal({ type: 'session', block });
  const start = block => {
    if (!state.logs[block.occurrenceId]?.done) updateLog(block, { started: true, snooze: null });
    session(block);
  };
  const close = () => setModal(null);
  const add = (date, skill) => setModal({ type: 'edit', date, draft: skill ? { skill } : undefined });
  const daysOfWeek = Array.from({ length: 7 }, (_, i) => addDays(week, i));
  const todayBlocks = blocksOn(state, today);
  const remaining = todayBlocks.filter(block => !state.logs[block.occurrenceId]?.done);
  const next = remaining.find(block => block.time >= new Date().toTimeString().slice(0, 5)) || remaining[0];
  const completed = Object.values(state.logs).filter(log => log.done && log.block).sort((a, b) => b.date.localeCompare(a.date));
  const changeView = tab => { setView(tab); scroll.current?.scrollTo({ y: 0, animated: false }); };
  const moveWeek = offset => {
    const nextWeek = addDays(week, offset * 7);
    setWeek(nextWeek); setDay(addDays(nextWeek, weekday(day)));
  };

  function saveBlock(draft) {
    const { occurrenceId, cancelled, ...fields } = draft;
    commit(current => {
      if (modal.scope === 'one') {
        const source = modal.source;
        const logs = { ...current.logs };
        const log = logs[source.occurrenceId];
        if (log) logs[source.occurrenceId] = { ...log, block: { ...fields, occurrenceId: source.occurrenceId },
          date: fields.date, skill: fields.skill, snooze: null };
        return { ...current, logs, overrides: { ...current.overrides,
          [source.occurrenceId]: { ...fields, occurrenceId: source.occurrenceId } } };
      }
      const existing = current.blocks.some(item => item.id === fields.id);
      return { ...current, blocks: existing ? current.blocks.map(item => item.id === fields.id ? fields : item) : [...current.blocks, fields] };
    });
    setMessage('Sesión guardada.');
    close();
  }
  function deleteBlock() {
    const { source, scope } = modal;
    commit(current => {
      if (scope === 'one') return { ...current, overrides: { ...current.overrides, [source.occurrenceId]: { cancelled: true } } };
      const overrides = Object.fromEntries(Object.entries(current.overrides).filter(([entry]) => !entry.startsWith(source.id + '@')));
      return { ...current, overrides, blocks: current.blocks.filter(block => block.id !== source.id) };
    });
    setMessage(scope === 'one' ? 'Sesión cancelada.' : 'Horario eliminado.');
    close();
  }
  async function restore() {
    try {
      const data = await importBackup();
      if (data) setModal({ type: 'restore', data: validate(data) });
    } catch { setMessage('No se pudo importar esa copia de DailyEnglish.'); }
  }
  const scheduledWeek = (date, dense) => {
    const sessions = blocksOn(state, date);
    const off = state.settings.rest.includes(weekday(date)) || pausedOn(state, date);
    return <View key={date} style={{ flex: dense ? 1 : undefined, gap: 8 }}>
      {!dense && <Text weight="800">{longDate(date)}</Text>}
      {off && <Text muted size={13}>Descanso</Text>}
      {sessions.map(block => <SessionTile key={block.occurrenceId} block={block} log={state.logs[block.occurrenceId]} onPress={() => session(block)} />)}
      <Button kind="chip" label={dense ? '+' : '+ Añadir bloque'} accessibilityLabel={'Añadir bloque el ' + longDate(date)} onPress={() => add(date)} />
    </View>;
  };
  return <Theme.Provider value={p}>
    <SafeAreaView style={{ backgroundColor: p.bg, flex: 1 }}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} />
      <View style={{ width: '100%', maxWidth: 1080, alignSelf: 'center', flex: 1 }}>
        <View style={{ ...between, paddingHorizontal: 20, paddingVertical: 11, borderBottomWidth: 1, borderColor: p.line }}>
          <View style={row}>
            <Brand />
            <Text weight="800" size={21}>DailyEnglish</Text>
          </View>
          <Button label="⚙" accessibilityLabel="Ajustes" onPress={() => setModal({ type: 'settings' })} disabled={!ready} />
        </View>
        {!ready ? <View style={{ padding: 20 }}><Text>Cargando tu horario…</Text></View> :
          <ScrollView ref={scroll} contentContainerStyle={{ padding: 20, gap: 15, paddingBottom: 32 }}>
            {!!message && <Card style={{ backgroundColor: p.soft }}><View style={between}>
              <Text accessibilityRole="alert" style={{ flex: 1 }}>{message}</Text>
              <Button label="×" accessibilityLabel="Cerrar mensaje" onPress={() => setMessage('')} />
            </View></Card>}
            {view === 'Hoy' && <>
              <View style={{ gap: 5 }}><Text muted>{longDate(today)}</Text><Title size={36}>Hoy</Title></View>
              <Card style={{ backgroundColor: p.hero, borderColor: p.hero, padding: 22, gap: 12 }}>
                <Text size={13} weight="800" color={p.lime}>{next ? 'PRÓXIMA SESIÓN' : todayBlocks.length ? 'ESTUDIO DE HOY' : 'TU HORARIO'}</Text>
                <Text size={29} weight="800" color={p.white}>{next ? next.skill : todayBlocks.length ? 'Sesiones completadas' : state.settings.rest.includes(weekday(today)) || pausedOn(state, today) ? 'Día de descanso' : 'Tu próximo bloque de inglés'}</Text>
                <Text color="#DCEFE3">{next ? [next.time, next.minutes + ' min', next.objective || next.title].filter(Boolean).join(' · ')
                  : todayBlocks.length ? 'Ya registraste el estudio de hoy.' : 'Crea una sesión o empieza con una plantilla.'}</Text>
                <View style={wrap}>
                  <Button kind="bright" label={next ? 'Empezar sesión ›' : '+ Añadir sesión'} onPress={() => next ? start(next) : add(today)} />
                  <Button label={next ? 'Ver sesión' : 'Plantillas'} onPress={() => next ? session(next) : setModal({ type: 'templates' })} />
                </View>
              </Card>
              <Card>
                <View style={between}><Title size={19}>Meta semanal</Title><Text weight="800">{Math.round(ratio * 100)} %</Text></View>
                <Bar value={ratio} label="Meta semanal" />
                <Text muted>{duration(stats.minutes)} de {duration(state.settings.goal)}</Text>
              </Card>
              {!!todayBlocks.length && <Title size={21}>Sesiones de hoy</Title>}
              {todayBlocks.map(block => <SessionTile key={block.occurrenceId} block={block} log={state.logs[block.occurrenceId]} onPress={() => session(block)} />)}
            </>}
            {view === 'Horario' && <>
              <View style={between}><Title>Horario</Title><Button label="Plantillas" onPress={() => setModal({ type: 'templates' })} /></View>
              <Card>
                <View style={between}>
                  <Button label="‹" accessibilityLabel="Semana anterior" onPress={() => moveWeek(-1)} />
                  <Text size={16} weight="800">{shortDate(week)} – {shortDate(addDays(week, 6))}</Text>
                  <Button label="›" accessibilityLabel="Semana siguiente" onPress={() => moveWeek(1)} />
                </View>
                <View style={wrap}>{daysOfWeek.map((date, i) => <Button key={date} kind="chip"
                  label={days[i] + ' ' + fromKey(date).getDate() + (blocksOn(state, date).length ? ' •' : '')}
                  selected={day === date} onPress={() => setDay(date)} />)}</View>
                <Button label="Volver a esta semana" onPress={() => { setWeek(monday(today)); setDay(today); }} />
              </Card>
              {width >= 930 ? <View style={{ flexDirection: 'row', gap: 8 }}>
                {daysOfWeek.map(date => <View key={date} style={{ flex: 1, gap: 8 }}>
                  <Text weight="800">{days[weekday(date)]} {fromKey(date).getDate()}</Text>{scheduledWeek(date, true)}
                </View>)}
              </View> : <>
                {scheduledWeek(day, false)}
                <Title size={19}>Resto de la semana</Title>
                {daysOfWeek.filter(date => date !== day).map(date => scheduledWeek(date, false))}
              </>}
            </>}
            {view === 'Progreso' && <>
              <Title>Progreso</Title>
              <Card>
                <View style={between}><Title size={20}>Esta semana</Title><Text weight="800">{Math.round(ratio * 100)} %</Text></View>
                <Text size={29} weight="800">{duration(stats.minutes)}</Text>
                <Bar value={ratio} label="Meta semanal" />
                <Text muted>Meta {duration(state.settings.goal)} · Planificados {duration(stats.planned)}</Text>
                <Text weight="700">{stats.entries.length} sesiones hechas · Racha de {streak(state, today)} días</Text>
              </Card>
              <Card>
                <Title size={20}>Minutos por día</Title>
                {days.map((label, index) => {
                  const date = addDays(monday(today), index);
                  const minutes = stats.entries.filter(item => item.date === date).reduce((sum, item) => sum + item.minutes, 0);
                  return <View key={label} style={between}><Text>{label}</Text><Text muted>{minutes} min</Text></View>;
                })}
              </Card>
              <Card>
                <Title size={20}>Tiempo por habilidad</Title>
                {Object.entries(stats.bySkill).map(([skill, mins]) => <View key={skill} style={{ gap: 5 }}>
                  <View style={between}><Text>{skills[skill][0]} {skill}</Text><Text muted>{mins} min</Text></View>
                  <Bar value={stats.minutes ? mins / stats.minutes : 0} color={skills[skill][3]} label={skill} />
                </View>)}
              </Card>
              {state.settings.balance && stats.minutes >= 30 && stats.bySkill.Speaking * 5 < stats.minutes &&
                !Array.from({ length: 7 }, (_, i) => addDays(monday(today), i)).filter(date => date >= today)
                  .some(date => blocksOn(state, date).some(block => block.skill === 'Speaking' && !state.logs[block.occurrenceId]?.done)) &&
                <Card style={{ backgroundColor: p.soft }}>
                  <Title size={19}>Un poco más de Speaking</Title>
                  <Text>¿Te quedan 15 minutos para practicar una conversación esta semana?</Text>
                  <Button label="+ Agregar Speaking" onPress={() => setModal({ type: 'edit', date: today, draft: { skill: 'Speaking', minutes: 15 } })} />
                </Card>}
              <Title size={20}>Historial</Title>
              {completed.length ? completed.map(log => <View key={log.block.occurrenceId} style={{ gap: 4 }}>
                <Text muted>{shortDate(log.date)} · {log.minutes} min registrados</Text>
                <SessionTile block={log.block} log={log} onPress={() => session(log.block)} />
              </View>) : <Text muted>Tus sesiones hechas aparecerán aquí.</Text>}
              {!!state.phrases.length && <Card><Title size={20}>Frases guardadas</Title>
                {state.phrases.map(phrase => <Text key={phrase.id}>{phrase.text}</Text>)}</Card>}
            </>}
          </ScrollView>}
        <View style={{ ...row, padding: 9, borderTopWidth: 1, borderColor: p.line, backgroundColor: p.card }}>
          {tabs.map(([icon, tab]) => <Button key={tab} label={icon + '  ' + tab} accessibilityLabel={tab}
            kind="chip" selected={view === tab} style={{ flex: 1, paddingHorizontal: 4 }} onPress={() => changeView(tab)} />)}
          <Button kind="solid" label="+" accessibilityLabel="Nueva sesión" onPress={() => add(view === 'Horario' ? day : today)} disabled={!ready} />
        </View>
      </View>

      {modal?.type === 'settings' && <Settings settings={state.settings} notice={notice} close={close}
        save={settings => { commit(current => ({ ...current, settings })); close(); }}
        activate={() => sync(true)} test={() => sync(true, true)}
        backup={() => exportBackup(state).catch(() => setMessage('No se pudo exportar la copia.'))} restore={restore} />}
      {modal?.type === 'templates' && <TemplateForm date={today} close={close} custom={state.customTemplates}
        weekToSave={daysOfWeek.flatMap((date, index) => blocksOn(state, date).map(block => ({ ...block, day: index })))}
        onSave={(name, blocks) => {
          const templateId = id();
          commit(current => ({ ...current, customTemplates: [...current.customTemplates,
            { name, blocks, goal: current.settings.goal, id: templateId }] }));
          return templateId;
        }} apply={(blocks, goal) => {
        commit(current => ({ ...current, blocks: [...current.blocks, ...blocks],
          settings: goal ? { ...current.settings, goal } : current.settings }));
        const startDate = blocks[0].date;
        setWeek(monday(startDate)); setDay(startDate);
        setMessage('Plantilla añadida al horario.');
        changeView('Horario'); close();
      }} />}
      {modal?.type === 'edit' && <BlockForm block={modal.draft} scope={modal.scope} date={modal.date} close={close}
        save={saveBlock} cancel={modal.source && (() => setModal({ ...modal, type: 'delete' }))} />}
      {modal?.type === 'delete' && <Sheet title="Quitar del horario" close={close}>
        <Text>{modal.scope === 'one' ? 'Se cancelará este bloque y sus avisos.' : 'Se eliminará este horario y se cancelarán sus avisos.'} El estudio registrado seguirá en tu historial.</Text>
        <Button kind="solid" label="Confirmar" onPress={deleteBlock} />
        <Button label="Volver a editar" onPress={() => setModal({ ...modal, type: 'edit' })} />
      </Sheet>}
      {modal?.type === 'session' && <Session key={modal.block.occurrenceId} block={modal.block}
        log={state.logs[modal.block.occurrenceId] || blankLog} settings={state.settings} close={close}
        update={changes => updateLog(modal.block, changes)} phrases={state.phrases}
        addPhrase={phrase => commit(current => ({ ...current, phrases: [...current.phrases, phrase] }))}
        edit={phrase => {
          const source = modal.block;
          const original = state.blocks.find(item => item.id === source.id);
          if (typeof phrase === 'string') setModal({ type: 'edit', scope: 'one', source, date: source.date,
            draft: { ...source, tasks: [...source.tasks, 'Repasar: ' + phrase] } });
          else if (original?.days.length) setModal({ type: 'scope', source, original });
          else if (original) setModal({ type: 'edit', scope: 'one', source, draft: source, date: source.date });
          else {
            setModal({ type: 'edit', date: today, draft: { ...source, date: today, days: [], id: id() } });
          }
        }} />}
      {modal?.type === 'scope' && <Sheet title="Editar sesión" close={close}>
        <Button label="Solo esta sesión" onPress={() => setModal({ type: 'edit', scope: 'one', source: modal.source, draft: modal.source, date: modal.source.date })} />
        <Button label="Toda la serie" onPress={() => setModal({ type: 'edit', scope: 'all', source: modal.source, draft: modal.original, date: modal.original.date })} />
        <Button label="Duplicar como sesión nueva" onPress={() => setModal({ type: 'edit', date: modal.source.date,
          draft: { ...modal.source, days: [], until: '', id: id() } })} />
      </Sheet>}
      {modal?.type === 'restore' && <Sheet title="Restaurar copia" close={close}>
        <Text>La copia reemplazará el horario, el progreso y los ajustes guardados en este dispositivo.</Text>
        <Button kind="solid" label="Reemplazar con la copia" onPress={() => { commit(() => modal.data); setMessage('Copia restaurada.'); close(); }} />
      </Sheet>}
    </SafeAreaView>
  </Theme.Provider>;
}

export default function App() {
  return <SafeAreaProvider><AppContent /></SafeAreaProvider>;
}

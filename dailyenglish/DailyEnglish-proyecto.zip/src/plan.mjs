export const skills = {
  Listening: ['🎧', '#D9EBFD', '#17436D', '#4986BD'],
  Speaking: ['🎙', '#FCE4D4', '#753112', '#C36137'],
  Reading: ['📖', '#E4F0D1', '#325014', '#689340'],
  Writing: ['✍', '#F0E1F9', '#5A3280', '#9661BD'],
  Vocabulario: ['Aa', '#FFEDBA', '#67460A', '#A7751A'],
  Gramática: ['✓', '#D9F2EE', '#215C56', '#498D82'],
  'Práctica B2': ['B2', '#E6E6FF', '#393477', '#726AC4'],
};

export const days = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
export const reminders = { none: 'Sin aviso', before: '10 min antes', exact: 'A la hora', both: 'Ambos' };
export const id = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
const pad = value => String(value).padStart(2, '0');
export function key(date = new Date()) {
  return [date.getFullYear(), pad(date.getMonth() + 1), pad(date.getDate())].join('-');
}
export function fromKey(date) {
  const [year, month, day] = date.split('-').map(Number);
  return new Date(year, month - 1, day);
}
export function addDays(date, count) {
  const next = fromKey(date);
  next.setDate(next.getDate() + count);
  return key(next);
}
export const weekday = date => (fromKey(date).getDay() + 6) % 7;
export const monday = date => addDays(date, -weekday(date));
export function when(date, time) {
  const result = fromKey(date);
  const [hour, minute] = time.split(':').map(Number);
  result.setHours(hour, minute);
  return result.getTime();
}
export const validDate = date => typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date) && key(fromKey(date)) === date;
export const validTime = time => typeof time === 'string' && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time);
export const occurrence = (block, date) => ({ ...block, date, occurrenceId: block.id + '@' + date });
export function blocksOn(state, date) {
  return state.blocks.filter(block => {
    if (block.date > date || (block.until && date > block.until)) return false;
    if (block.days.length) return block.days.includes(weekday(date));
    return block.date === date;
  }).map(block => {
    const entry = occurrence(block, date);
    const change = state.overrides[entry.occurrenceId];
    return change ? { ...entry, ...change } : entry;
  }).filter(block => !block.cancelled && block.date === date).concat(
    Object.values(state.overrides).filter(block => !block.cancelled && block.date === date && !blocksOnOriginal(state, block, date)),
  ).sort((a, b) => a.time.localeCompare(b.time));
}
function blocksOnOriginal(state, entry, date) {
  const source = state.blocks.find(block => block.id === entry.id);
  return source && entry.occurrenceId === occurrence(source, date).occurrenceId
    && source.date <= date && (!source.until || date <= source.until)
    && (source.days.length ? source.days.includes(weekday(date)) : source.date === date);
}
export const pausedOn = (state, date) => Boolean(state.settings.pauseFrom && state.settings.pauseTo
  && date >= state.settings.pauseFrom && date <= state.settings.pauseTo);
export function pendingReminders(state, now = Date.now()) {
  const today = key(new Date(now));
  const notices = [];
  const dates = new Set(Array.from({ length: 57 }, (_, index) => addDays(today, index - 1)));
  for (const block of state.blocks) {
    if (block.date > today) {
      for (let offset = 0; offset < (block.days.length ? 7 : 1); offset++) dates.add(addDays(block.date, offset));
    }
  }
  for (const change of Object.values(state.overrides)) {
    if (!change.cancelled && change.date >= today) dates.add(change.date);
  }
  for (const date of dates) {
    if (pausedOn(state, date)) continue;
    for (const block of blocksOn(state, date)) {
      const log = state.logs[block.occurrenceId];
      if (log?.done || (date < today && !log?.snooze)) continue;
      const mode = block.reminder || state.settings.reminder;
      const start = when(date, block.time);
      const offsets = log?.snooze ? ['snooze'] : {
        none: [], before: [10], exact: [0], both: [10, 0],
      }[mode] || [];
      for (const offset of offsets) {
        const at = offset === 'snooze' ? log.snooze : start - offset * 60_000;
        if (at <= now || (log?.started && offset !== 'snooze')) continue;
        notices.push({ at, block, before: offset === 10, id: 'study-' + block.occurrenceId + '-' + offset + '-' + at });
      }
    }
  }
  return notices.sort((a, b) => a.at - b.at).slice(0, 60);
}
export const initialState = () => ({
  version: 1,
  blocks: [],
  overrides: {},
  logs: {},
  phrases: [],
  customTemplates: [],
  settings: {
    goal: 240, reminder: 'before', theme: 'system', rest: [6], balance: true,
    pauseFrom: '', pauseTo: '', speakFlow: '', readingStudio: '',
  },
});

export function weekStats(state, date) {
  const start = monday(date);
  const end = addDays(start, 6);
  const entries = Object.values(state.logs).filter(log => log.done && log.date >= start && log.date <= end);
  const bySkill = Object.fromEntries(Object.keys(skills).map(skill => [skill, 0]));
  for (const log of entries) {
    if (log.skill in bySkill) bySkill[log.skill] += log.minutes;
  }
  const planned = Array.from({ length: 7 }, (_, i) => blocksOn(state, addDays(start, i)))
    .flat().reduce((sum, block) => sum + block.minutes, 0);
  return { entries, bySkill, planned, minutes: entries.reduce((sum, log) => sum + log.minutes, 0) };
}
export function streak(state, today) {
  const dates = new Set(Object.values(state.logs).filter(log => log.done).map(log => log.date));
  if (!dates.size) return 0;
  const first = [...dates].sort()[0];
  let count = 0;
  for (let cursor = dates.has(today) ? today : addDays(today, -1); cursor >= first; cursor = addDays(cursor, -1)) {
    if (dates.has(cursor)) count++;
    else if (!state.settings.rest.includes(weekday(cursor)) && !pausedOn(state, cursor)) break;
  }
  return count;
}
export const templates = {
  suave: { title: 'Suave', description: '3 sesiones de 20 minutos cada semana', goal: 60 },
  intensivo: { title: 'Intensivo', description: '6 sesiones de 45 minutos cada semana', goal: 270 },
  b2: { title: 'Plan B2 en 8 semanas', description: '4 sesiones semanales de 35 minutos, con diagnóstico y simulacros', goal: 140 },
};
const exercises = {
  Listening: ['Escucha un audio', 'Anota tres frases útiles'],
  Speaking: ['Haz shadowing durante 15 min', 'Responde tres preguntas en voz alta'],
  Reading: ['Lee un texto corto', 'Resume la idea principal'],
  Writing: ['Escribe un párrafo', 'Revisa conectores y errores'],
  Vocabulario: ['Repasa 10 phrasal verbs', 'Escribe tres ejemplos'],
  Gramática: ['Repasa una regla', 'Escribe cinco ejemplos'],
  'Práctica B2': ['Resuelve un ejercicio con tiempo', 'Revisa las respuestas'],
};
export function makeTemplate(name, date, time) {
  const create = (skill, day, minutes, offset = 0, weeks = 0, title = '') => ({
    id: id(), skill, date: addDays(date, offset * 7), days: [day], time, minutes, title,
    until: weeks ? addDays(date, (offset + weeks) * 7 - 1) : '',
    tasks: exercises[skill], objective: '', link: '', reminder: '', focus: 25, rest: 5,
  });
  if (name === 'suave') return ['Listening', 'Speaking', 'Vocabulario'].map((skill, i) => create(skill, i * 2, 20));
  if (name === 'intensivo') return ['Listening', 'Speaking', 'Reading', 'Writing', 'Gramática', 'Práctica B2']
    .map((skill, i) => create(skill, i, 45));
  const phases = [
    [0, 2, 'Diagnóstico y bases', ['Listening', 'Speaking', 'Gramática', 'Práctica B2']],
    [2, 4, 'Práctica de habilidades', ['Reading', 'Speaking', 'Listening', 'Writing']],
    [6, 2, 'Simulacros y revisión', ['Práctica B2', 'Speaking', 'Writing', 'Práctica B2']],
  ];
  return phases.flatMap(([offset, weeks, title, list]) =>
    list.map((skill, i) => create(skill, [0, 2, 4, 5][i], 35, offset, weeks, title)));
}

export async function exportBackup(state) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'DailyEnglish-copia.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function importBackup() {
  return new Promise((resolve, reject) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.oncancel = () => resolve(null);
    input.onchange = async () => {
      try { resolve(input.files[0] ? JSON.parse(await input.files[0].text()) : null); }
      catch (error) { reject(error); }
    };
    input.click();
  });
}

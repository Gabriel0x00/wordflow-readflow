import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as Picker from 'expo-document-picker';

export async function exportBackup(state) {
  const logs = Object.fromEntries(Object.entries(state.logs).map(([entryId, log]) => {
    const { recording, ...data } = log;
    return [entryId, data];
  }));
  const file = new File(Paths.cache, 'DailyEnglish-copia.json');
  file.create({ overwrite: true });
  file.write(JSON.stringify({ ...state, logs }, null, 2));
  await Sharing.shareAsync(file.uri, { mimeType: 'application/json', dialogTitle: 'Guardar copia de DailyEnglish' });
}
export async function importBackup() {
  const result = await Picker.getDocumentAsync({ type: 'application/json', copyToCacheDirectory: true });
  if (result.canceled) return null;
  return JSON.parse(await new File(result.assets[0].uri).text());
}
